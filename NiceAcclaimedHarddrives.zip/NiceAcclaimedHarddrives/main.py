import discord
from discord.ext import commands
from discord.ui import Select, View, Modal, TextInput
from discord.utils import get
from datetime import datetime
import aiohttp
import os
import json

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)
bot.remove_command("help")

# Gamepass ID (str) -> Role ID (str)
gamepass_roles = {
    'Premium Basic': ('945234682', '1297630539745853511'),
    'Premium Plus': ('945096067', '1297630539745853512'),
    'Premium Ultra': ('945064117', '1297630539745853513'),
}

log_channel_id = 1297630542442795034
ownership_check_url = "https://your-replit-url.repl.co/check-ownership"
premium_file = 'premium_users_expiry.json'

if not os.path.exists(premium_file):
    with open(premium_file, 'w') as f:
        json.dump({"active": {}}, f)

def load_premium_data():
    with open(premium_file, 'r') as f:
        return json.load(f)

def save_premium_data(data):
    with open(premium_file, 'w') as f:
        json.dump(data, f, indent=4)

def create_embed(title, description, color=discord.Color.blurple()):
    return discord.Embed(title=title, description=description, color=color)

async def verify_gamepass_ownership(username, gamepass_id):
    async with aiohttp.ClientSession() as session:
        async with session.get(ownership_check_url, params={"username": username, "gamepassId": gamepass_id}) as resp:
            if resp.status == 200:
                result = await resp.json()
                return result.get("owns", False)
            return False

class RobloxUsernameModal(Modal, title="Enter Roblox Username"):
    def __init__(self, chosen_option, user):
        super().__init__()
        self.chosen_option = chosen_option
        self.user = user
        self.username = TextInput(label="Roblox Username", placeholder="Your Roblox username", required=True)
        self.add_item(self.username)

    async def on_submit(self, interaction: discord.Interaction):
        roblox_username = self.username.value.strip()
        gamepass_id, role_id = gamepass_roles[self.chosen_option]
        owns_gamepass = await verify_gamepass_ownership(roblox_username, gamepass_id)

        if not owns_gamepass:
            await interaction.response.send_message(embed=create_embed("Verification Failed", f"❌ **{roblox_username}** does not own the required gamepass.", discord.Color.red()), ephemeral=True)
            return

        # Give role
        role = get(interaction.guild.roles, id=int(role_id))
        if role:
            await self.user.add_roles(role)
        else:
            await interaction.response.send_message(embed=create_embed("Error", "❌ Role not found."), ephemeral=True)
            return

        # Log it
        log_channel = interaction.guild.get_channel(log_channel_id)
        if log_channel:
            now = datetime.utcnow()
            embed = discord.Embed(
                title="✅ Premium Granted",
                color=discord.Color.green()
            )
            embed.add_field(name="Roblox Username", value=roblox_username, inline=True)
            embed.add_field(name="Premium Tier", value=self.chosen_option, inline=True)
            embed.add_field(name="Discord User", value=f"{self.user.mention} ({self.user.id})", inline=False)
            embed.set_footer(text=f"Granted at {now.strftime('%Y-%m-%d %H:%M:%S UTC')}")
            await log_channel.send(embed=embed)

        # Save data
        data = load_premium_data()
        data["active"][str(self.user.id)] = {
            "roblox_username": roblox_username,
            "premium_option": self.chosen_option,
            "granted_at": datetime.utcnow().isoformat()
        }
        save_premium_data(data)

        await interaction.response.send_message(embed=create_embed("Premium Granted", f"✅ You now have **{self.chosen_option}** premium!", discord.Color.green()), ephemeral=True)

@bot.tree.command(name="buy_premium", description="Start the premium purchase process")
async def buy_premium(interaction: discord.Interaction):
    select = Select(
        placeholder="Choose your premium option",
        min_values=1,
        max_values=1,
        options=[discord.SelectOption(label=label) for label in gamepass_roles.keys()]
    )

    async def select_callback(select_interaction: discord.Interaction):
        chosen_option = select_interaction.data['values'][0]
        modal = RobloxUsernameModal(chosen_option, select_interaction.user)
        await select_interaction.response.send_modal(modal)

    view = View()
    select.callback = select_callback
    view.add_item(select)
    await interaction.response.send_message(embed=create_embed("Premium Purchase", "Choose a premium tier below."), view=view, ephemeral=True)

@bot.event
async def on_ready():
    print(f"Bot is ready. Logged in as {bot.user}")
    try:
        synced = await bot.tree.sync()
        print(f"Synced {len(synced)} commands.")
    except Exception as e:
        print(f"Sync failed: {e}")

# Run the bot
bot.run(os.getenv("DISCORD_TOKEN"))
